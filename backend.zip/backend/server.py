from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Form
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timezone
import aiofiles
from PIL import Image
import json

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create upload directory
UPLOAD_DIR = ROOT_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Mount static files
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")

# Pydantic Models
class MedicalImage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    original_filename: str
    file_path: str
    file_size: int
    diagnosis_type: Optional[str] = None
    body_location: Optional[str] = None
    patient_age: Optional[int] = None
    patient_gender: Optional[str] = None
    description: Optional[str] = None
    upload_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    uploader_name: Optional[str] = None

class MedicalImageCreate(BaseModel):
    diagnosis_type: Optional[str] = None
    body_location: Optional[str] = None
    patient_age: Optional[int] = None
    patient_gender: Optional[str] = None
    description: Optional[str] = None
    uploader_name: Optional[str] = None

class Statistics(BaseModel):
    total_images: int
    diagnosis_types: dict
    body_locations: dict
    recent_uploads: int
    gender_distribution: dict
    age_distribution: dict

class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: str
    role: str = "researcher"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    total_uploads: int = 0

class UserCreate(BaseModel):
    name: str
    email: str
    role: str = "researcher"

# Helper functions
def prepare_for_mongo(data):
    """Convert datetime objects to strings for MongoDB storage"""
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, datetime):
                data[key] = value.isoformat()
    return data

def parse_from_mongo(item):
    """Convert datetime strings back to datetime objects"""
    if isinstance(item, dict):
        for key, value in item.items():
            if key in ['upload_date', 'created_at'] and isinstance(value, str):
                try:
                    item[key] = datetime.fromisoformat(value)
                except:
                    pass
    return item

# API Routes

@api_router.get("/")
async def root():
    return {"message": "SkinCancer DB API", "version": "1.0.0"}

# Image Upload Routes
@api_router.post("/images/upload", response_model=MedicalImage)
async def upload_image(
    file: UploadFile = File(...),
    diagnosis_type: Optional[str] = Form(None),
    body_location: Optional[str] = Form(None),
    patient_age: Optional[int] = Form(None),
    patient_gender: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    uploader_name: Optional[str] = Form(None)
):
    # Validate file type
    if not file.content_type.startswith('image/'):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Generate unique filename
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'jpg'
    unique_filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = UPLOAD_DIR / unique_filename
    
    # Save file
    try:
        async with aiofiles.open(file_path, 'wb') as f:
            content = await file.read()
            await f.write(content)
        
        # Get file size
        file_size = len(content)
        
        # Validate image
        try:
            img = Image.open(file_path)
            img.verify()
        except Exception:
            # Remove invalid file
            os.unlink(file_path)
            raise HTTPException(status_code=400, detail="Invalid image file")
        
        # Create medical image record
        medical_image = MedicalImage(
            filename=unique_filename,
            original_filename=file.filename,
            file_path=f"/uploads/{unique_filename}",
            file_size=file_size,
            diagnosis_type=diagnosis_type,
            body_location=body_location,
            patient_age=patient_age,
            patient_gender=patient_gender,
            description=description,
            uploader_name=uploader_name
        )
        
        # Save to database
        image_dict = prepare_for_mongo(medical_image.dict())
        await db.medical_images.insert_one(image_dict)
        
        return medical_image
        
    except Exception as e:
        # Cleanup file if exists
        if file_path.exists():
            os.unlink(file_path)
        raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")

@api_router.get("/images", response_model=List[MedicalImage])
async def get_images(skip: int = 0, limit: int = 50):
    images = await db.medical_images.find().skip(skip).limit(limit).sort("upload_date", -1).to_list(length=None)
    return [MedicalImage(**parse_from_mongo(image)) for image in images]

@api_router.get("/images/{image_id}", response_model=MedicalImage)
async def get_image(image_id: str):
    image = await db.medical_images.find_one({"id": image_id})
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    return MedicalImage(**parse_from_mongo(image))

@api_router.delete("/images/{image_id}")
async def delete_image(image_id: str):
    image = await db.medical_images.find_one({"id": image_id})
    if not image:
        raise HTTPException(status_code=404, detail="Image not found")
    
    # Delete file
    file_path = UPLOAD_DIR / image['filename']
    if file_path.exists():
        os.unlink(file_path)
    
    # Delete from database
    await db.medical_images.delete_one({"id": image_id})
    return {"message": "Image deleted successfully"}

# Statistics Routes
@api_router.get("/statistics", response_model=Statistics)
async def get_statistics():
    # Get total images
    total_images = await db.medical_images.count_documents({})
    
    # Get diagnosis types distribution
    diagnosis_pipeline = [
        {"$group": {"_id": "$diagnosis_type", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    diagnosis_types = {}
    async for result in db.medical_images.aggregate(diagnosis_pipeline):
        diagnosis_types[result["_id"] or "Unknown"] = result["count"]
    
    # Get body locations distribution
    location_pipeline = [
        {"$group": {"_id": "$body_location", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    body_locations = {}
    async for result in db.medical_images.aggregate(location_pipeline):
        body_locations[result["_id"] or "Unknown"] = result["count"]
    
    # Get recent uploads (last 7 days)
    from datetime import timedelta
    seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
    recent_uploads = await db.medical_images.count_documents({
        "upload_date": {"$gte": seven_days_ago.isoformat()}
    })
    
    # Get gender distribution
    gender_pipeline = [
        {"$group": {"_id": "$patient_gender", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    gender_distribution = {}
    async for result in db.medical_images.aggregate(gender_pipeline):
        gender_distribution[result["_id"] or "Unknown"] = result["count"]
    
    # Get age distribution (grouped by ranges)
    age_pipeline = [
        {
            "$addFields": {
                "age_group": {
                    "$switch": {
                        "branches": [
                            {"case": {"$lt": ["$patient_age", 18]}, "then": "0-17"},
                            {"case": {"$lt": ["$patient_age", 30]}, "then": "18-29"},
                            {"case": {"$lt": ["$patient_age", 50]}, "then": "30-49"},
                            {"case": {"$lt": ["$patient_age", 70]}, "then": "50-69"},
                            {"case": {"$gte": ["$patient_age", 70]}, "then": "70+"}
                        ],
                        "default": "Unknown"
                    }
                }
            }
        },
        {"$group": {"_id": "$age_group", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    age_distribution = {}
    async for result in db.medical_images.aggregate(age_pipeline):
        age_distribution[result["_id"]] = result["count"]
    
    return Statistics(
        total_images=total_images,
        diagnosis_types=diagnosis_types,
        body_locations=body_locations,
        recent_uploads=recent_uploads,
        gender_distribution=gender_distribution,
        age_distribution=age_distribution
    )

# User Management Routes
@api_router.post("/users", response_model=User)
async def create_user(user: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="User with this email already exists")
    
    new_user = User(**user.dict())
    user_dict = prepare_for_mongo(new_user.dict())
    await db.users.insert_one(user_dict)
    return new_user

@api_router.get("/users", response_model=List[User])
async def get_users(skip: int = 0, limit: int = 50):
    users = await db.users.find().skip(skip).limit(limit).sort("created_at", -1).to_list(length=None)
    return [User(**parse_from_mongo(user)) for user in users]

@api_router.get("/users/{user_id}", response_model=User)
async def get_user(user_id: str):
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return User(**parse_from_mongo(user))

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()